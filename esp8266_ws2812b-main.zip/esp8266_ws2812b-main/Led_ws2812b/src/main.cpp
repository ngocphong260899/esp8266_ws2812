#include <Arduino.h>
#define FASTLED_ESP8266_RAW_PIN_ORDER
#include "FastLED.h"
#include "html_pages.h"
#include <ESP8266WiFi.h>
#include <ESP8266WebServer.h>
#include <string.h>

#define LED_PIN D1
#define LED_STATUS  D0
#define NUM_LEDS 120

IPAddress local_IP(192,168,4,20);
IPAddress gateway(192,168,4,9);
IPAddress subnet(255,255,255,0);

const char* ssid = "Dungnt98-esp";
// const char* password = "12345678";

/* start server with port 80 */
ESP8266WebServer server(80);

CRGBArray<NUM_LEDS> leds;
static uint8_t hue;
String rgb_now = "#0000ff";
long red_int = 0;
long green_int = 0;
long blue_int = 255;
int brightness = 30;

void handleRootPath();
void handleNotFound();
void handleSwitchOn();
void handleSwitchOff();
void handleSetColour();
void handleSelectMode();
void handleSetBrightness();
void handleBrightness();
void handleColour();
void light_up_all();
void turn_off_all();
void set_color(int R, int B, int G);

void setup() {
    Serial.begin(9600);

    /* Led init */
    FastLED.addLeds<NEOPIXEL,LED_PIN>(leds, NUM_LEDS);
    FastLED.setBrightness(brightness);
    pinMode(LED_STATUS, OUTPUT);

    /* Wifi Access Point config */
    WiFi.softAPConfig(local_IP, gateway, subnet);
    WiFi.softAP(ssid);
    IPAddress IP = WiFi.softAPIP();

    /* Print ESP8266 Local IP Address */
    Serial.print("AP IP address: ");
    Serial.println(IP);
    Serial.println(WiFi.localIP());

    /* Web server */
    server.on("/", handleRootPath);
    server.onNotFound ( handleNotFound );
    server.on ( "/switch_on", handleSwitchOn);
    server.on ( "/switch_off", handleSwitchOff);
    server.on ( "/set_colour", handleSetColour);
    server.on ( "/set_colour_hash", handleColour );
    server.on ( "/set_brightness", handleSetBrightness);
    server.on ( "/set_bright_val", handleBrightness);
    server.on ( "/select_mode", handleSelectMode);
    server.begin();

    light_up_all();
}

void loop() {
    server.handleClient(); 
    digitalWrite(LED_STATUS, !digitalRead(LED_STATUS));
}

void handleRootPath() {
    server.send(200, "text/html", page_contents);

    if(server.hasArg("LED1")) {
        String led1 = server.arg("LED1"); // nếu có thì sẽ lấy dữ liệu của LED1 chứa.
        Serial.println("LED1=");
        Serial.println(led1);

        if(led1 == "OFF") // nếu dữ liệu chứa bằng "ON"
            digitalWrite(LED_STATUS, HIGH); // bật LED1
        else
            digitalWrite(LED_STATUS, LOW); // tắt LED1
    }
}


void handleNotFound() {
  String message = "File Not Found\n\n";
  message += "URI: ";
  message += server.uri();
  message += "\nMethod: ";
  message += ( server.method() == HTTP_GET ) ? "GET" : "POST";
  message += "\nArguments: ";
  message += server.args();
  message += "\n";

  for ( uint8_t i = 0; i < server.args(); i++ ) {
    message += " " + server.argName ( i ) + ": " + server.arg ( i ) + "\n";
  }

  server.send ( 404, "text/plain", message);
}

void handleSwitchOn() {            
    light_up_all();
    server.send(200, "text/html", "<SCRIPT language='JavaScript'>window.location='/';</SCRIPT>" );
};  

void handleSwitchOff() {
    turn_off_all();
    server.send ( 200, "text/html", "<SCRIPT language='JavaScript'>window.location='/';</SCRIPT>" );
}

void handleSetColour() {     
    server.send ( 200, "text/html", colour_picker);
}

void handleSetBrightness() {
    server.send ( 200, "text/html", bright_set);
    String java_redirect = "<SCRIPT language='JavaScript'>window.location='/set_brightness?";
            java_redirect += brightness;                                              //send brightness value in URL to update the slider control
            java_redirect += "';</SCRIPT>";
    server.send ( 200, "text/html", java_redirect); 
}  

void handleSelectMode() {
server.send ( 200, "text/html", mode_page );
//  Serial.println ( "Mode select page" );
}


void handleColour() {
    char buf_red[3];                               //char buffers to hold 'String' value converted to char array
    char buf_green[3];                       
    char buf_blue[3];                       
    String message = server.arg(0);                //get the 1st argument from the url which is the hex rgb value from the colour picker ie. #rrggbb (actually %23rrggbb)
    rgb_now = message; 
    rgb_now.replace("%23", "#");                   // change %23 to # as we need this in one of html pages
    String red_val = rgb_now.substring(1,3);       //extract the rgb values
    String green_val = rgb_now.substring(3,5); 
    String blue_val = rgb_now.substring(5,7);

    red_val.toCharArray(buf_red,3);                //convert hex 'String'  to Char[] for use in strtol() 
    green_val.toCharArray(buf_green,3);           
    blue_val.toCharArray(buf_blue,3);             

    red_int = gamma_adjust[strtol( buf_red, NULL, 16)];          //convert hex chars to ints and apply gamma adjust
    green_int = gamma_adjust[strtol( buf_green, NULL, 16)];
    blue_int = gamma_adjust[strtol( buf_blue, NULL, 16)];

    set_color(red_int, green_int, blue_int);

    String java_redirect = "<SCRIPT language='JavaScript'>window.location='/set_colour?";
            java_redirect += message;                                                 //send hash colour value in URL to update the colour picker control
            java_redirect += "';</SCRIPT>";
    server.send ( 200, "text/html", java_redirect );                                 // all done! - take user back to the colour picking page                                                                                          
}

void handleBrightness() {
    String message = server.arg(0);                //get the 1st argument from the url which is the brightness level set by the slider
    String bright_val = message.substring(0,3);    //extract the brightness value from the end of the argument in the URL
    brightness =  bright_val.toInt();

    FastLED.setBrightness(brightness);
    FastLED.delay(33);

    String java_redirect = "<SCRIPT language='JavaScript'>window.location='/set_brightness?";
            java_redirect += brightness;                                              //send brightness value in URL to update the slider control
            java_redirect += "';</SCRIPT>";
    server.send ( 200, "text/html", java_redirect);                                  // all done! - take user back to the brightness selection page                                                                                          
}

void light_up_all() {
    /* Control led trip */
    set_color(red_int, green_int, blue_int); 
    FastLED.delay(33);                                                                                                                       
}

void turn_off_all() {
    for(int i = 0; i < NUM_LEDS; i++) {   
        leds[i] = CRGB(0,0,0);
    }
    FastLED.delay(33);                                                                                                                      // This sends the updated pixel color to the hardware.
}

void set_color(int R, int B, int G) {
    for(int i = 0; i < NUM_LEDS; i++) {   
        leds[i] = CRGB(R,B,G);
    } 
    FastLED.delay(33);
}